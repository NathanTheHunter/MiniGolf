﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace Word_Tally
{
    class Program
    {
        static void Main(string[] args)
        {
            string data = File.ReadAllText("passage.txt");
            data = data.ToLower();
            int totalwordcount = 0;
            Regex rgx = new Regex(@"[^a-z\s]");
            Regex whtspc = new Regex(@"\s+");
            string list = rgx.Replace(data, "");
            list = rgx.Replace(list, "");
            string[] List = list.Split(' ');
            for (int z = 0; z <= List.Length-1; z++) {
                List[z] = whtspc.Replace(List[z], "");
            }
            SortedDictionary<string, int> dit = new SortedDictionary<string, int>();
            for (int i = 0; i <= List.Length-1; i++) {
                if (dit.ContainsKey(List[i]) == false && List[i] != null && List[i] != "")
                {
                    dit.Add(List[i], 1);
                    totalwordcount++;
                }
                else if (dit.ContainsKey(List[i]) == true && List[i] != "") {
                    int count;
                    dit.TryGetValue(List[i], out count);
                    count++;
                    dit.Remove(List[i]);
                    dit.Add(List[i], count);
                }                    
            }
            foreach (var item in dit.OrderByDescending(key=>key.Value)) {

            }
                StreamWriter sw = new StreamWriter("tallies.txt");
                sw.WriteLine("WORD---------------------COUNT");
                sw.WriteLine("------------------------------");
                foreach (KeyValuePair<string, int> kvp in dit){
                if (kvp.Key == null || kvp.Key == " " || kvp.Key == "  ")
                {

                }
                else
                {
                    sw.Write(kvp.Key);
                    string k = Convert.ToString(kvp.Value);
                    for (int s = 0; s <= 30 - kvp.Key.Length - k.Length; s++)
                    {
                        sw.Write(" ");
                    }
                    sw.WriteLine(k);
                }

                }
        }

        }
    }

