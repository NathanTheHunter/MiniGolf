﻿ __      __                .___ ___________      .__  .__         
/  \    /  \___________  __| _/ \__    ___/____  |  | |  | ___.__.
\   \/\/   /  _ \_  __ \/ __ |    |    |  \__  \ |  | |  |<   |  |
 \        (  <_> )  | \/ /_/ |    |    |   / __ \|  |_|  |_\___  |
  \__/\  / \____/|__|  \____ |    |____|  (____  /____/____/ ____|
       \/                   \/                 \/          \/     

PROBLEM DESCRIPTION
---------------------------------------------------------------------------------------------------
Write a program to tally the instances of words in a text passage.

INPUT SPECIFICATION
---------------------------------------------------------------------------------------------------
The input file "passage.txt" contains the text passage.

OUTPUT SPECIFICATION
---------------------------------------------------------------------------------------------------
The output file "tallies.txt" contains the count for each word in the passage.  Be sure to match
the sample output exactly.

RESTRICTIONS
---------------------------------------------------------------------------------------------------
There are no restrictions for this challenge.  You can use any language features.